module.exports = require('./renderer');
